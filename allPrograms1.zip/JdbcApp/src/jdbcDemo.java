
public class jdbcDemo {

	public static void main(String[] args) {
		
		try {
			
			Class.forName( , null)
			
			
		} catch (ClassCastException e) {
			
			e.printStackTrace();
		}
	}

}
