
public class mainArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Area a = new Area();
		a.circleArea();
		a.triangleArea();
	}

}
