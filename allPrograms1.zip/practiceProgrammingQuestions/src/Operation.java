
public class Operation {
	
	public void addData(int n1,int n2)
	{
		int add =n1+n2;
		System.out.println("Add is: "+add);
		
	}
	public void subData(int n1,int n2)
	{
		int sub =n1-n2;
		System.out.println("Sub is: "+sub);
		
	}
	public void mulData(int n1,int n2)
	{
		int mul =n1*n2;
		System.out.println("Sub is: "+mul);
		
	}
	public void divData(float n1,float n2)
	{
		float div =n1/n2;
		System.out.println("Sub is: "+div);
		
	}
}
