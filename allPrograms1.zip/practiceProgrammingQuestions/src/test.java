
public class test {
	
		public int roll;
		public float marks;
		public String name;
	}

