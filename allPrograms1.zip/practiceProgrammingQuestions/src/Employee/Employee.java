package Employee;

public class Employee {

		private int empid;
		private String empName;
		private double empsalary;
		
}
