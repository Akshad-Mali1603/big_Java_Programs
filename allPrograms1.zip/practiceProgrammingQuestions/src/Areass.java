
public class Areass {
			
	public float circlea(float r) {
		return (float) (Math.PI*r*r);
	}
	public float trianglea(float b,float h) {
		
		return 0.5f*b*h;
	}
	public float rectanglea(float l,float bh) {
		
		return l*bh;
	}
	
}
