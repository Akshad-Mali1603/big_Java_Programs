
public class funmain {

	public static void main(String[] args) {
		functions f =new functions();
//		f.prime();
//		f.reverse();
//		f.sumofnum();
//		f.max();
//		f.min();
		f.perfect();
		

	}

}
