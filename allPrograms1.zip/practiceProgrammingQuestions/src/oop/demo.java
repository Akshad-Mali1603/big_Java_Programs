package oop;

public class demo {

}
//hide data abstraction
//binding of data is called encapsulation
//using parents function 
//use of same data types in different methods:1] overloading- 
//2]overriding-inheritance is always use
//
//