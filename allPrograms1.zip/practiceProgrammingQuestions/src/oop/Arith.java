package oop;

public class Arith {

		public int add(int a,int b) {
			return a+b;
		}
		public int add(int a,int b,int c) {
			return a+b+c;
		}
		public int add(int a,int b,int c,int d) {
			return a+b+c+d;
		}
		public int add(int a,int b,int c,int d,int e) {
			return a+b+c+d+e;
		}
		public int add(int a,int b ,int c, int d, int e,int f) {
			return a+b+c+d+e+f ;
		}
}
