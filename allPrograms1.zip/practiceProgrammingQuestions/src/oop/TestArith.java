package oop;

public class TestArith {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		Arith arith = new Arith();
		
		System.out.println(arith.add(10,20,50,20,30,1));
	}

}
