
public class addition {

	public static void main(String[] args) {
		int a = 10;
		int b = 31;
		System.out.println("add is :" + (a + b));
	}

}
