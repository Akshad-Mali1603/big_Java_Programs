
public class TestAddition {

	public static void main(String[] args) {
		Addition add= new Addition();
		add.run();
	}

}
