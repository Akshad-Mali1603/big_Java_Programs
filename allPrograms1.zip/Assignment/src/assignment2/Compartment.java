package assignment2;

public abstract class Compartment {
	public abstract void Notice();
}
