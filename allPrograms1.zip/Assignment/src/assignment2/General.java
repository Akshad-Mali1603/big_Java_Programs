package assignment2;

public class General extends Compartment {

	@Override
	public void Notice() {
		// TODO Auto-generated method stub
		System.out.println("Notice: You are in General Class !!!");
	}

}
