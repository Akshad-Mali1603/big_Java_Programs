package assignment2;

public class Ladies extends Compartment {

	@Override
	public void Notice() {
		// TODO Auto-generated method stub
		System.out.println("Notice: You are in Ladies Compartment !!!");
	}

}
