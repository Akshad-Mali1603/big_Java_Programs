package assignment2;

public class FirstClass extends Compartment {

	@Override
	public void Notice() {
		// TODO Auto-generated method stub
		System.out.println("Notice: You are in the First Class !!!");
	}

}
