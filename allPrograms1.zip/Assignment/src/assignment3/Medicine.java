package assignment3;

public abstract class Medicine {
	public void displayLabel() {
	  System.out.println("Company Name: a drug manufactured by a AKS pharmaceutical company");
	  System.out.println("Address: Shivajinager Pune !!!");	
	}
}
