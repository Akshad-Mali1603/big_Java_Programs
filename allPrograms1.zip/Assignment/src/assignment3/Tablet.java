package assignment3;

public class Tablet extends Medicine {
	@Override
	public void displayLabel() {
		super.displayLabel();
		System.out.println("Tablet could be store in a cool dry place\n");
	}
}
