package assignment3;

public class Syrup extends Medicine {
	@Override
	public void displayLabel() {
		super.displayLabel();
		System.out.println("Syrup could be Shake well before use\n");
	}
}
