package testFileHandling;

import java.net.URL;

public class testEmpRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 employeeServices emp= new employeeServices();
	 emp.fileInsert();
	 
	}

}
