package super_class;

public interface Operations {
		void create();
		void display();
		float getSalary();
		void update(int choice, Object data);
		
}
