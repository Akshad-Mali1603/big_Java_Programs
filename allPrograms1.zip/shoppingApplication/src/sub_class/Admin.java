package sub_class;

public class Admin {
	
	private String email="Akshad16";
	private String password="Akshad16";
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
			
}
