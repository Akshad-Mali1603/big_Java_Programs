package constructor1;

public class module {
		int account;
		String accountType;
		String accountOwner;
		float accountBalance;
		
		
		public module() {
			
		}
		public module(int no, String name, String type,float amt) {
			this.account = no;
			this.accountBalance= amt;
			this.
		}
}
