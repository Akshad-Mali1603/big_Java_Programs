/**
 * 
 */
/**
 * @author DELL
 *
 */
module myjdbc {
	requires java.sql;
}