package collectionR;

public class Stream1 {

	void main() {
		System.out.println("Hello world");
	}

}
