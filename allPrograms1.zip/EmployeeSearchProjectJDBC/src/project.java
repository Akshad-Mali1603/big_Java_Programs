
public class project {
	private int id;
	private String name;
	private String technology;
	public project() {
		super();
		// TODO Auto-generated constructor stub
	}
	public project(int id, String name, String technology) {
		super();
		this.id = id;
		this.name = name;
		this.technology = technology;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	@Override
	public String toString() {
		return "project [id=" + id + ", name=" + name + ", technology=" + technology + "]";
	}
	
}
