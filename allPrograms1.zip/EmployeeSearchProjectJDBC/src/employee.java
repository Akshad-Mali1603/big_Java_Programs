
public class employee {
		private int id;
		private String name;
		private float salary;
		private int did;
		private int pid;
		public employee() {
			super();
			// TODO Auto-generated constructor stub
		}
		public employee(int id, String name, float salary, int did, int pid) {
			super();
			this.id = id;
			this.name = name;
			this.salary = salary;
			this.did = did;
			this.pid = pid;
		}
		public employee(int id, String name, float salary) {
			super();
			this.id = id;
			this.name = name;
			this.salary = salary;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public float getSalary() {
			return salary;
		}
		public void setSalary(float salary) {
			this.salary = salary;
		}
		public int getDid() {
			return did;
		}
		public void setDid(int did) {
			this.did = did;
		}
		public int getPid() {
			return pid;
		}
		public void setPid(int pid) {
			this.pid = pid;
		}
		@Override
		public String toString() {
			return "employee [id=" + id + ", name=" + name + ", salary=" + salary + ", did=" + did + ", pid=" + pid
					+ "]";
		}
		
		
		
}
