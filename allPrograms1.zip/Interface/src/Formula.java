
public interface Formula {
	float pi=3.14f;
	float areacir(float a);
	float percir(float a);
	float areasq(float a);
	float persq(float a);
	float arearec(float a, float b);
	float perrec(float a, float b);
	
}
