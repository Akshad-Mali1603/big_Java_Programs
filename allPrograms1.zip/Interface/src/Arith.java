
public interface Arith {
	
	float add(float a,float b);
	float sub(float a,float b);
	float mul(float a,float b);
	float div(float a,float b);
	
}
