
public class Number implements Arith {

	@Override
	public float add(float a, float b) {
		// TODO Auto-generated method stub
		return a+b;
	}

	@Override
	public float sub(float a, float b) {
		// TODO Auto-generated method stub
		return a-b;
	}

	@Override
	public float mul(float a, float b) {
		// TODO Auto-generated method stub
		return a*b;
	}

	@Override
	public float div(float a, float b) {
		// TODO Auto-generated method stub
		return a/b;
	}

}
